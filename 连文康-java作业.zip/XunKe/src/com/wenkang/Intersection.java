package com.wenkang;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.wenkang.bean.User;

public class Intersection {
	
	public void intersections(List<String> list1,List<String> list2) {	//�ַ�������
		
		List<String> result = new ArrayList<String>(); 
		for (String s:list1) {
			
			if(list2.contains(s)){
				
				result.add(s);
				
			}
			
		}
		System.out.println("�ظ���Ԫ�أ�"+result);
	}
	
	public void Userintection(List<User> user1,List<User> user2) {	//User����
		
		List<User> user = new ArrayList<>();
		
		for (User a : user2) {
			for (User b : user1) {
				if(a.getId().equals(b.getId()) && a.getName().equals(b.getName()) && 
						a.getSex().equals(b.getSex())){
					user.add(b);
				}
			}
			
		}
		System.out.println(user);
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<String> list1 = new ArrayList<String>();
		List<String> list2 = new ArrayList<String>();
		List<User> user1 = new ArrayList<User>();
		List<User> user2 = new ArrayList<User>();
		list1.add("1");
		list1.add("2");
		list1.add("3");
		list1.add("4");
		list1.add("5");
		list1.add("6");
		list2.add("2");
		list2.add("4");
		list2.add("6");
		list2.add("8");
		list2.add("10");
		user1.add(new User("A", "Saber", "Ů"));
		user2.add(new User("A", "Saber", "Ů"));
		user1.add(new User("B", "master", "Ů"));
		user1.add(new User("C", "Archer", "��"));
		user1.add(new User("D", "Lancer", "��"));
		user2.add(new User("E", "Rider", "Ů"));
		user2.add(new User("F", "Berserker", "��"));
		user2.add(new User("G", "Caster", "Ů"));
		
		Intersection intersection = new Intersection();
		intersection.intersections(list1, list2);
		intersection.Userintection(user1, user2);
		
	}

}
